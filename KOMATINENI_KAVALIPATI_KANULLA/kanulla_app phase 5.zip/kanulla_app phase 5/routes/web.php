<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Kanullaapp;
use App\Http\Controllers\UIFromScratch;

Route::get('/', [Kanullaapp::class,"defaultPage"]);

Route::get('/student_portal/add_clubs.php',[Kanullaapp::class,"addClubs"])->name("add_clubs.php");
Route::post('/student_portal/add_clubs.php',[Kanullaapp::class,"addClubs"])->name("add_clubs.php");

Route::get('/student_portal/add_posts.php',[Kanullaapp::class,"addPosts"])->name("add_posts.php");
Route::post('/student_portal/add_posts.php',[Kanullaapp::class,"addPosts"])->name("add_posts.php");

Route::get('/student_portal/add_product.php',[Kanullaapp::class,"addProduct"])->name("add_product.php");
Route::post('/student_portal/add_product.php',[Kanullaapp::class,"addProduct"])->name("add_product.php");

Route::get('/student_portal/add_promotion.php',[Kanullaapp::class,"addPromotion"])->name("add_promotion.php");
Route::post('/student_portal/add_promotion.php',[Kanullaapp::class,"addPromotion"])->name("add_promotion.php");

Route::get('/student_portal/cart.php',[Kanullaapp::class,"cart"])->name("cart.php");
Route::post('/student_portal/cart.php',[Kanullaapp::class,"cart"])->name("cart.php");

Route::get('/student_portal/chat.php',[Kanullaapp::class,"chat"])->name("chat.php");
Route::post('/student_portal/chat.php',[Kanullaapp::class,"chat"])->name("chat.php");

Route::get('/student_portal/clubs.php',[Kanullaapp::class,"clubs"])->name("clubs.php");
Route::post('/student_portal/clubs.php',[Kanullaapp::class,"clubs"])->name("clubs.php");

Route::get('/student_portal/contact_us.php',[Kanullaapp::class,"contactUs"])->name("contact_us.php");
Route::post('/student_portal/contact_us.php',[Kanullaapp::class,"contactUs"])->name("contact_us.php");

Route::get('/student_portal/get_contacts.php',[Kanullaapp::class,"getContacts"])->name("get_contacts.php");
Route::post('/student_portal/get_contacts.php',[Kanullaapp::class,"getContacts"])->name("get_contacts.php");

Route::get('/student_portal/get_users.php',[Kanullaapp::class,"getUsers"])->name("get_users.php");
Route::post('/student_portal/get_users.php',[Kanullaapp::class,"getUsers"])->name("get_users.php");

Route::get('/student_portal/manage_users.php',[Kanullaapp::class,"manageUsers"])->name("manage_users.php");
Route::post('/student_portal/manage_users.php',[Kanullaapp::class,"manageUsers"])->name("manage_users.php");

Route::get('/student_portal/orders.php',[Kanullaapp::class,"orders"])->name("orders.php");
Route::post('/student_portal/orders.php',[Kanullaapp::class,"orders"])->name("orders.php");

Route::get('/student_portal/register.php',[Kanullaapp::class,"register"])->name("register.php");
Route::post('/student_portal/register.php',[Kanullaapp::class,"register"])->name("register.php");

Route::post('/upload.php',[Kanullaapp::class,"upload"])->name("upload.php");


//UI from scratch

Route::get('/login',[UIFromScratch::class,"loginSignUp"])->name("upload.php");
Route::post('/login',[UIFromScratch::class,"loginSignUp"])->name("upload.php");
//portal links:    

Route::get('/student-home',[UIFromScratch::class,"studentHome"])->name("student-home");
Route::get('/school-admin-home',[UIFromScratch::class,"schoolAdminHome"])->name("school-admin-home");
Route::get('/business-owner-home',[UIFromScratch::class,"businessOwnerHome"])->name("business-owner-home");
Route::get('/add-club',[UIFromScratch::class,"addClub"])->name("add-club");
Route::get('/add-get',[UIFromScratch::class,"addget"])->name("add-get");
Route::get('/add-product',[UIFromScratch::class,"addProduct"])->name("add-product");
//manage-clubs 
Route::get('/chat',[UIFromScratch::class,"chat"])->name("chat");

Route::get('/cart',[UIFromScratch::class,"cart"])->name("cart");
Route::get('/manage-users',[UIFromScratch::class,"manageUsers"])->name("manage-users");
Route::get('/manage-students',[UIFromScratch::class,"manageStudents"])->name("manage-students");
Route::get('/manage-business-owners',[UIFromScratch::class,"manageBusinessOwners"])->name("manage-business-owners");
Route::get('/manage-school-admins',[UIFromScratch::class,"manageSchoolAdmins"])->name("manage-school-admins");

Route::get('/manage-promotions',[UIFromScratch::class,"manageSchoolAdmins"])->name("manage-school-admins");
/*


Route::get('/manage-clubs',[UIFromScratch::class,"manageClubs"])->name("manage-clubs");
Route::get('/manage-clubs',[UIFromScratch::class,"manageClubs"])->name("manage-clubs");
Route::get('/manage-clubs',[UIFromScratch::class,"manageClubs"])->name("manage-clubs");
Route::get('/manage-clubs',[UIFromScratch::class,"manageClubs"])->name("manage-clubs"); */
