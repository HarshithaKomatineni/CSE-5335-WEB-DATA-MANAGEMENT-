<?php

namespace App\Http\Controllers;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Redirect;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Input;

class Kanullaapp extends Controller
{

    public function chat(Request $request){
        $json = file_get_contents('php://input');
        $data = json_decode($json);
        $payload=$data;

        switch ($data->type) {
            case 'insert':
                if (!empty($payload->chat_from) && !empty($payload->message) && !empty($payload->added_by)) {

       $cres=DB::insert("INSERT INTO chatbox (chat_from, message, added_by) VALUES (?,?,?)",[$payload->chat_from,$payload->message,$payload->added_by]);
        if ($cres === TRUE) {
            $resp = array("success"=>true, "message"=>"Record Created Successfully");
            echo json_encode($resp);
        } else {
            $resp = array("success"=>false, "message"=>"Record Creation Failed");
            echo json_encode($resp);
        }
    } else {
        $resp = array("success"=>false, "message"=>"Missing Mandatory Fields");
        echo json_encode($resp);
    }
                break;

            case 'select':
                $sql = "SELECT id, chat_from, message, added_by FROM chatbox where added_by = '".$payload->user_id."' ORDER BY id ASC";
                $result = DB::select($sql);

                if (count($result) > 0) {
                    $my_products = array();
                    foreach($result as $row){
                        $response = array("id"=>$row->id, "chat_from"=>$row->chat_from, "message"=>$row->message, "added_by"=>$row->added_by);
                        array_push($my_products, $response);
                    }
                    $resp = array("success"=>true, "data"=>json_encode($my_products));
                    echo json_encode($resp);
                } else {
                    $resp = array("success"=>false, "message"=>"No User Exist with this Email. Please Register to Login.");
                    echo json_encode($resp);
                }
                break;



            default:
                // code...
                break;
        }
    }
    
    public function addClubs(Request $request){

        $json = file_get_contents('php://input');
        $data = json_decode($json);
        $payload=$data;
        switch ($data->type) {
            case 'select':
                    if (!empty($payload->user_id)) {
                            $sql = "SELECT id, club_name, club_type, club_image, created_date FROM clubs where added_by = '".$payload->user_id."' and status=1";
                        } else {
                            $sql = "SELECT id, club_name, club_type, club_image, created_date FROM clubs where status=1";
                        }
                        $result = DB::select($sql);

                        if (count($result) > 0) {
                            $my_products = array();
                            foreach($result as $row){
                                $response = array("id"=>$row->id, "club_name"=>$row->club_name, "club_type"=>$row->club_type, "club_image"=>$row->club_image, "created_date"=>$row->created_date);
                                array_push($my_products, $response);
                            }
                            $resp = array("success"=>true, "data"=>json_encode($my_products));
                            echo json_encode($resp);
                        } else {
                            $resp = array("success"=>false, "message"=>"Unable to Load Products");
                            echo json_encode($resp);
                        }
                break;
            
            case 'update':

                     $sql = "UPDATE clubs SET status=2 WHERE id='".$payload->club_id."'";
                        $r=DB::update($sql);
                        if ($r === TRUE) {
                            $resp = array("success"=>true, "message"=>"Updated Successfully");
                            echo json_encode($resp);
                        } else {
                            $resp = array("success"=>false, "message"=>"Failed to Update");
                            echo json_encode($resp);
                        }

                
                break;

            case 'insert':
                if (!empty($payload->club_name) && !empty($payload->club_type) && !empty($payload->club_image)) {
                        
                        $reps=DB::insert("INSERT INTO clubs (club_name, club_type, club_image, added_by) VALUES (?,?,?,?)",[$payload->club_name,$payload->club_type,$payload->club_image,$payload->user_id]);

                        if ($reps === TRUE) {
                            $resp = array("success"=>true, "message"=>"Record Created Successfully");
                            echo json_encode($resp);
                        } else {
                            $resp = array("success"=>false, "message"=>"Record Creation Failed");
                            echo json_encode($resp);
                        }
                    } else {
                        $resp = array("success"=>false, "message"=>"Missing Mandatory Fields");
                        echo json_encode($resp);
                    }
                break;

            default:
                // code...
                break;
        }

    }

    public function addPosts(Request $request){

        $json = file_get_contents('php://input');
        $data = json_decode($json);
        $payload=$data;
        switch ($data->type) {
            case 'select':
                if (!empty($payload->user_id)) {
                    $sql = "SELECT id, post_title, post_desp, post_image, created_date FROM posts where added_by = '".$payload->user_id."'";
                } else {
                    $sql = "SELECT id, post_title, post_desp, post_image, created_date FROM posts";
                }
                $result =DB::select($sql);

                if (count($result) > 0) {
                    $my_products = array();
                    foreach($result as $row) {
                        $response = array("id"=>$row->id, "post_title"=>$row->post_title, "post_desp"=>$row->post_desp, "post_image"=>$row->post_image, "created_date"=>$row->created_date);
                        array_push($my_products, $response);
                    }
                    $resp = array("success"=>true, "data"=>json_encode($my_products));
                    echo json_encode($resp);
                } else {
                    $resp = array("success"=>false, "message"=>"Unable to Load Products");
                    echo json_encode($resp);
                }
                break;
            
            case 'update':
                
                break;

            case 'insert':
                     if (!empty($payload->post_title) && !empty($payload->post_desp) && !empty($payload->post_image)) {

                                $cres=DB::insert("INSERT INTO posts (post_title, post_desp, post_image, added_by) VALUES (?,?,?,?)",[$payload->post_title,$payload->post_desp,$payload->post_image,$payload->user_id]);
                            if ($cres === TRUE) {
                                $resp = array("success"=>true, "message"=>"Record Created Successfully");
                                echo json_encode($resp);
                            } else {
                                $resp = array("success"=>false, "message"=>"Record Creation Failed");
                                echo json_encode($resp);
                            }
                        } else {
                            $resp = array("success"=>false, "message"=>"Missing Mandatory Fields");
                            echo json_encode($resp);
                        }
                break;

            default:
                // code...
                break;
        }

    }
    public function addProduct(Request $request){

        $json = file_get_contents('php://input');
        $data = json_decode($json);
        $payload=$data;

        switch ($data->type) {
            case 'select':
                     if (!empty($payload->user_id)) {
                            $sql = "SELECT id, product_name, product_type, product_image, product_price FROM products where added_by = '".$payload->user_id."' and status=1";
                        } else {
                            $sql = "SELECT id, product_name, product_type, product_image, product_price FROM products where status=1";
                        }
                        $result =DB::select($sql);

                        if (count($result)> 0) {
                            $my_products = array();
                            foreach($result as $row){
                                $response = array("id"=>$row->id, "product_name"=>$row->product_name, "product_type"=>$row->product_type, "product_image"=>$row->product_image, "product_price"=>$row->product_price);
                                array_push($my_products, $response);
                            }
                            $resp = array("success"=>true, "data"=>json_encode($my_products));
                            echo json_encode($resp);
                        } else {
                            $resp = array("success"=>false, "message"=>"Unable to Load Products");
                            echo json_encode($resp);
                        }
                break;
            
            case 'update':
                $sql = "UPDATE products SET status=2 WHERE id='".$payload->product_id."'";
                $dr=DB::update($sql);
                if ($dr === TRUE) {
                    $resp = array("success"=>true, "message"=>"Updated Successfully");
                    echo json_encode($resp);
                } else {
                    $resp = array("success"=>false, "message"=>"Failed to Update");
                    echo json_encode($resp);
                }
                break;

            case 'insert':
                if (!empty($payload->product_name) && !empty($payload->product_type) && !empty($payload->product_image) && !empty($payload->product_price)) {

                        $cres=DB::insert("INSERT INTO products (product_name, product_type, product_image, product_price, added_by) VALUES (?,?,?,?,?)",[$payload->product_name,$payload->product_type,$payload->product_image,$payload->product_price,$payload->user_id]);

                        if ($cres === TRUE) {
                            $resp = array("success"=>true, "message"=>"Record Created Successfully");
                            echo json_encode($resp);
                        } else {
                            $resp = array("success"=>false, "message"=>"Record Creation Failed");
                            echo json_encode($resp);
                        }
                    } else {
                        $resp = array("success"=>false, "message"=>"Missing Mandatory Fields");
                        echo json_encode($resp);
                    }
                break;

            default:
                // code...
                break;
        }

    }

    public function addPromotion(Request $request){

        $json = file_get_contents('php://input');
        $data = json_decode($json);
        $payload=$data;

        switch ($data->type) {
            case 'select':
                if (!empty($payload->prod_name) && !empty($payload->promotion_type) && !empty($payload->approach_media) && !empty($payload->product_message)) {

                    $cres=DB::insert("INSERT INTO promotions (prod_name, promotion_type, approach_media, product_message, added_by) VALUES (?,?,?,?,?)",[$payload->prod_name,$payload->promotion_type,$payload->approach_media,$payload->product_message,$payload->user_id]);
                    if ($cres === TRUE) {
                        $resp = array("success"=>true, "message"=>"Record Created Successfully");
                        echo json_encode($resp);
                    } else {
                        $resp = array("success"=>false, "message"=>"Record Creation Failed");
                        echo json_encode($resp);
                    }
                } else {
                    $resp = array("success"=>false, "message"=>"Missing Mandatory Fields");
                    echo json_encode($resp);
                }
                break;
            
            case 'update':
                
                break;

            case 'insert':
                
                break;

            default:
                // code...
                break;
        }

    }

    public function cart(Request $request){

        $json = file_get_contents('php://input');
        $data = json_decode($json);
        $payload=$data;
        switch ($data->type) {
            case 'select':
                $sql = "SELECT id, product_name, product_image, product_price, quantity FROM cart where added_by = '".$payload->user_id."' and status = 1";
                $result = DB::select($sql);

                if (count($result) > 0) {
                    $my_products = array();
                    foreach($result as $row){
                        $response = array("id"=>$row->id, "product_name"=>$row->product_name, "product_image"=>$row->product_image, "product_price"=>$row->product_price, "quantity"=>$row->quantity);
                        array_push($my_products, $response);
                    }
                    $resp = array("success"=>true, "data"=>json_encode($my_products));
                    echo json_encode($resp);
                } else {
                    $resp = array("success"=>false, "message"=>"No User Exist with this Email. Please Register to Login.");
                    echo json_encode($resp);
                }
                break;
            
            case 'update':
                if ((!empty($payload->action_type) && $payload->action_type == 'orders_page')) {
                        $sql = "UPDATE cart SET status=2 WHERE added_by='".$payload->added_by."'";
                    } else {
                        $sql = "UPDATE cart SET quantity='".$payload->quantity."' WHERE id='".$payload->cart_id."'";
                    }
                   $cres= DB::update($sql);
                    if ($cres === TRUE) {
                        $resp = array("success"=>true, "message"=>"Updated Successfully");
                        echo json_encode($resp);
                    } else {
                        $resp = array("success"=>false, "message"=>"Failed to Update");
                        echo json_encode($resp);
                    }
                break;

            case 'insert':
                if (!empty($payload->product_name) && !empty($payload->product_image) && !empty($payload->product_price) && !empty($payload->quantity) && !empty($payload->status) && !empty($payload->added_by)) {
                    

                    $cres=DB::insert("INSERT INTO cart (product_name, product_image, product_price, quantity, status, added_by) VALUES (?,?,?,?,?,?)",[$payload->product_name,$payload->product_image,$payload->product_price,$payload->quantity,$payload->status,$payload->added_by]);
                    if ($cres === TRUE) {
                        $resp = array("success"=>true, "message"=>"Record Created Successfully");
                        echo json_encode($resp);
                    } else {
                        $resp = array("success"=>false, "message"=>"Record Creation Failed");
                        echo json_encode($resp);
                    }
                } else {
                    $resp = array("success"=>false, "message"=>"Missing Mandatory Fields");
                    echo json_encode($resp);
                }
                break;

            case 'delete':
                $sql = "DELETE FROM cart WHERE id='".$payload->cart_id."'";
                $cres=DB::delete($sql);
                if ($cres === TRUE) {
                    $resp = array("success"=>true, "message"=>"Deleted Successfully");
                    echo json_encode($resp);
                } else {
                    $resp = array("success"=>false, "message"=>"Failed to Delete");
                    echo json_encode($resp);
                }
                break;

            default:
                // code...
                break;
        }

    }

    public function clubs(Request $request){

        $json = file_get_contents('php://input');
        $data = json_decode($json);
        $payload=$data;
        switch ($data->type) {
            case 'select':
                $sql = "SELECT id, club_name, club_type, club_image, created_date FROM clubs where added_by = '".$payload->user_id."'";
                $result = DB::select($sql);

                if (count($result) > 0) {
                    $my_products = array();
                    foreach($result as $row) {
                        $response = array("id"=>$row->id, "club_name"=>$row->club_name, "club_type"=>$row->club_type, "club_image"=>$row->club_image, "created_date"=>$row->created_date);
                        array_push($my_products, $response);
                    }
                    $resp = array("success"=>true, "data"=>json_encode($my_products));
                    echo json_encode($resp);
                } else {
                    $resp = array("success"=>false, "message"=>"Unable to Load Products");
                    echo json_encode($resp);
                }
                break;
            
            case 'update':
                // if ($payload->action_type == 'orders_page') {
                //     $sql = "UPDATE cart SET status=2 WHERE added_by='".$payload->added_by."'";
                // } else {
                //     $sql = "UPDATE cart SET quantity='".$payload->quantity."' WHERE id='".$payload->cart_id."'";
                // }

                // if ($connection->query($sql) === TRUE) {
                //     $resp = array("success"=>true, "message"=>"Updated Successfully");
                //     echo json_encode($resp);
                // } else {
                //     $resp = array("success"=>false, "message"=>"Failed to Update");
                //     echo json_encode($resp);
                // }
                break;

            case 'insert':
                if (!empty($payload->club_id) && !empty($payload->club_name) && !empty($payload->action) && !empty($payload->added_by)) {
                        if ($payload->action == 'leave') {
                            $sql = "DELETE FROM manage_clubs WHERE club_id='".$payload->club_id."' and action='join' and added_by='".$payload->added_by."'";

                            $cres=DB::delete($sql);

                            if ($connection->query($sql) === TRUE) {
                                $resp = array("success"=>true, "message"=>"Deleted Successfully");
                                echo json_encode($resp);
                            } else {
                                $resp = array("success"=>false, "message"=>"Failed to Leave");
                                echo json_encode($resp);
                            }
                        } else {
                            $num=1;

                                $cres=DB::insert("INSERT INTO manage_clubs (club_id, club_name, action, added_by, status) VALUES (?,?,?,?,?)",[$payload->club_id,$payload->club_name,$payload->action,$payload->added_by,$num]);

                            if ($cres === TRUE) {
                                $resp = array("success"=>true, "message"=>"Record Created Successfully");
                                echo json_encode($resp);
                            } else {
                                $resp = array("success"=>false, "message"=>"Record Creation Failed");
                                echo json_encode($resp);
                            }
                        }
                    } else {
                        $resp = array("success"=>false, "message"=>"Missing Mandatory Fields");
                        echo json_encode($resp);
                    }
                break;

            default:
                // code...
                break;
        }

    }

    public function contactUs(Request $request){

        $json = file_get_contents('php://input');
        $data = json_decode($json);
        $payload=$data;
        if (!empty($data->name) && !empty($data->email) && !empty($data->subject) && !empty($data->message)) {

            $cres=DB::insert("INSERT INTO contact_us (your_name, your_email, subject, message) VALUES (?,?,?,?)",[$data->name,$data->email,$data->subject,$data->message]);
            if ($cres === TRUE) {
                $resp = array("success"=>true, "message"=>"Record Created Successfully");
                echo json_encode($resp);
            } else {
                $resp = array("success"=>false, "message"=>"Record Creation Failed");
                echo json_encode($resp);
            }
        } else {
            $resp = array("success"=>false, "message"=>"Missing Mandatory Fields");
            echo json_encode($resp);
        }

    }

    public function getContacts(Request $request){

        $json = file_get_contents('php://input');
        $data = json_decode($json);
        $payload=$data;
        $sql = "SELECT id, your_name, your_email, subject, message FROM contact_us";
        $result = DB::select($sql);

        if (count($result)> 0) {
            $my_products = array();
            foreach($result as $row) {
                $response = array("id"=>$row->id, "your_name"=>$row->your_name, "your_email"=>$row->your_email, "subject"=>$row->subject, "message"=>$row->message);
                array_push($my_products, $response);
            }
            $resp = array("success"=>true, "data"=>json_encode($my_products));
            echo json_encode($resp);
        } else {
            $resp = array("success"=>false, "message"=>"No Queries Exist");
            echo json_encode($resp);
        }

    }

    public function getUsers(Request $request){

        $json = file_get_contents('php://input');
        $data = json_decode($json);
        $payload=$data;
        if($data->type == 'select') {
            $sql = "SELECT id FROM users where role = '".$payload->role."' and status=1";
            $result = DB::select($sql);

            if (count($result)> 0) {
                $my_products = array();
                foreach($result as $row){
                    $response = array("id"=>$row->id);
                    array_push($my_products, $response);
                }
                $resp = array("success"=>true, "data"=>json_encode($my_products));
                echo json_encode($resp);
            } else {
                $resp = array("success"=>false, "message"=>"");
                echo json_encode($resp);
            }
        }

    }

    public function manageUsers(Request $request){

        $json = file_get_contents('php://input');
        $data = json_decode($json);
        $payload=$data;
        switch ($data->type) {
            case 'select':
                $sql = "SELECT id, full_name, email, mobile_no, gender, password, role FROM users where role = '".$payload->role."' and status=1";
                    $result = DB::select($sql);

                    if (count($result) > 0) {
                        $my_products = array();
                        foreach($result as $row){
                            $response = array("id"=>$row->id, "full_name"=>$row->full_name, "email"=>$row->email, "mobile_no"=>$row->mobile_no, "gender"=>$row->gender, "role"=>$row->role);
                            array_push($my_products, $response);
                        }
                        $resp = array("success"=>true, "data"=>json_encode($my_products));
                        echo json_encode($resp);
                    } else {
                        $resp = array("success"=>false, "message"=>"No Users Exist");
                        echo json_encode($resp);
                    }
                break;
            
            case 'all':
                 $sql = "SELECT id, full_name, email, mobile_no, gender, password, role FROM users where status=1";
                    $result = DB::select($sql);

                    if (count($result) > 0) {
                        $my_products = array();
                        foreach($result as $row){
                            $response = array("id"=>$row->id, "full_name"=>$row->full_name, "email"=>$row->email, "mobile_no"=>$row->mobile_no, "gender"=>$row->gender, "role"=>$row->role);
                            array_push($my_products, $response);
                        }
                        $resp = array("success"=>true, "data"=>json_encode($my_products));
                        echo json_encode($resp);
                    } else {
                        $resp = array("success"=>false, "message"=>"No Users Exist");
                        echo json_encode($resp);
                    }
                break;

            case 'update':
                $sql = "UPDATE users SET status=2 WHERE id='".$payload->id."'";
                $cres=DB::update($sql);
                if ($cres === TRUE) {
                    $resp = array("success"=>true, "message"=>"Updated Successfully");
                    echo json_encode($resp);
                } else {
                    $resp = array("success"=>false, "message"=>"Failed to Update");
                    echo json_encode($resp);
                }
                break;

            default:
                // code...
                break;
        }

    }

    public function orders(Request $request){

        $json = file_get_contents('php://input');
        $data = json_decode($json);
        $payload=$data;
        switch ($data->type) {
            case 'select':
                $sql = "SELECT id, order_details, total, status, added_by FROM orders where added_by = '".$payload->user_id."' and status = 1 ORDER BY id DESC LIMIT 1";
                $result = DB::select($sql);

                if (count($result) > 0) {
                    $my_products = array();
                    foreach($result as $row){
                        $response = array("id"=>$row->id, "order_details"=>$row->order_details, "total"=>$row->total);
                        array_push($my_products, $response);
                    }
                    $resp = array("success"=>true, "data"=>json_encode($my_products));
                    echo json_encode($resp);
                } else {
                    $resp = array("success"=>false, "message"=>"No User Exist with this Email. Please Register to Login.");
                    echo json_encode($resp);
                }
                break;
            
            case 'update':
                $sql = "UPDATE orders SET order_details='".$payload->order_details."', payment_mode='".$payload->payment_mode."', payment_status='".$payload->payment_status."', order_number='".$payload->order_number."', status=2 WHERE id='".$payload->id."'";
                $cres=DB::update($sql);
                if ($cres === TRUE) {
                    $resp = array("success"=>true, "message"=>"Updated Successfully");
                    echo json_encode($resp);
                } else {
                    $resp = array("success"=>false, "message"=>"Failed to Update");
                    echo json_encode($resp);
                }
                break;

            case 'insert':
                if (!empty($payload->order_details) && !empty($payload->total) && !empty($payload->status) && !empty($payload->added_by)) {

                $cres=DB::insert("INSERT INTO orders (order_details, total, status, added_by) VALUES (?,?,?,?)",[$payload->order_details,$payload->total,$payload->status,$payload->added_by]);
                if ($cres=== TRUE) {
                    $resp = array("success"=>true, "message"=>"Record Created Successfully");
                    echo json_encode($resp);
                } else {
                    $resp = array("success"=>false, "message"=>"Record Creation Failed");
                    echo json_encode($resp);
                }
            } else {
                $resp = array("success"=>false, "message"=>"Missing Mandatory Fields");
                echo json_encode($resp);
            }
                break;

            default:
                // code...
                break;
        }

    }

    public function register(Request $request){

        $json = file_get_contents('php://input');
        $data = json_decode($json);
        $payload=$data;

        switch ($data->type) {
            case 'select':
                
                $sql = "SELECT id, full_name, email, mobile_no, gender, password, role FROM users where email = '".$payload->username."' and status=1";
                $result = DB::select($sql);

                if (count($result) > 0) {
                    foreach($result as $row){
                        $sys_pwd = base64_decode($row->password);
                        $cur_pwd = base64_decode($payload->password);
                        if ($sys_pwd == $cur_pwd) {
                            $response = array("id"=>$row->id, "full_name"=>$row->full_name, "email"=>$row->email, "mobile_no"=>$row->mobile_no, "gender"=>$row->gender, "role"=>$row->role);
                            $resp = array("success"=>true, "data"=>json_encode($response), "token"=>base64_encode(json_encode($response)));
                            echo json_encode($resp);
                        } else {
                            $resp = array("success"=>false, "message"=>"Invalid Username and Password");
                            echo json_encode($resp);
                        }
                    }
                } else {
                    $resp = array("success"=>false, "message"=>"No User Exist with this Email. Please Register to Login.");
                    echo json_encode($resp);
                }

                break;

            case 'insert':
                if (!empty($payload->name) && !empty($payload->email) && !empty($payload->mobile_no) && !empty($payload->gender) && !empty($payload->password)) {
                    

                    $cres=DB::insert("INSERT INTO users (full_name, email, mobile_no, gender, password, role) VALUES (?,?,?,?,?,?)",[$payload->name,$payload->email,$payload->mobile_no,$payload->gender,$payload->password,$payload->role]);

                    

                    if ($cres === TRUE) {
                        $resp = array("success"=>true, "message"=>"Record Created Successfully");
                        /* Mail::send([],[],function($message) using($email,$full_name){
                        $message->to($email);
                        $message->subject("REGISTRATION ON KANULLA'S APP -SUCCESS!");
                        $message->setBody("Dear ".$full_name.",<br> Your Registration on the app was successful.<br> Regards.");
                    }); */
                        echo json_encode($resp);
                    } else {
                        $resp = array("success"=>false, "message"=>"Record Creation Failed");
                        echo json_encode($resp);
                    }
                } else {
                    $resp = array("success"=>false, "message"=>"Missing Mandatory Fields");
                    echo json_encode($resp);
                }
                break;

            default:
                // code...
                break;
        }

    }

public function upload(Request $request){


$response = array();
$upload_dir = "images";
$server_url = 'http://127.0.0.1:8000/images';

if($request->file("avatar")) {
    $file=$request->file("avatar");

    $avatar_name = $file->getClientOriginalName();


        if($file->move($upload_dir,$avatar_name)) {
            $response = array(
                "status" => "success",
                "error" => false,
                "message" => "File uploaded successfully",
                "url" => $server_url."/".$avatar_name
              );
        } else {
            $response = array(
                "status" => "error",
                "error" => true,
                "message" => "Error uploading the file!"
            );
        }
    
} else{
    $response = array(
        "status" => "error",
        "error" => true,
        "message" => "No file was sent!"
    );
}

echo json_encode($response);







}



public function defaultPage(Request $request){

$resp = array("success"=>false, "message"=>"Missing Mandatory Fields");
                    echo json_encode($resp);

}


}
