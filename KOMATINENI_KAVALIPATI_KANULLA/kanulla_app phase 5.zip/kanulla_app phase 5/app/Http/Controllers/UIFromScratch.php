<?php

namespace App\Http\Controllers;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Redirect;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Input;

class UIFromScratch extends Controller
{
    public function loginSignUp(Request $request){
        $login_error=$signup_error="";
        $status=$request->input('status');
        if ($request->isMethod('post')) {
            if ($status=='signup') {
                $full_name=$request->input('full_name');
                $email=$request->input('email');
                $mobile_no=$request->input('mobile_no');
                $gender=$request->input('gender');
                $password=$request->input('password');
                $role=$request->input('role');
                $cres=DB::insert("INSERT INTO users (full_name, email, mobile_no, gender, password, role) VALUES (?,?,?,?,?,?)",[$name,$email,$mobile_no,$gender,$password,$role]);
                $signup_error="<div style='alert alert-danger'>sign up success. please login.</div>";
            }else{
                $username=$request->input('username');
                $password=$request->input('password');
                $re=DB::select("select * from users where email=? and Password=?",[$username,$password]);
                if (count($re) >0) {
                    foreach ($re as $k) {
                       \Session::put('full_name',$k->full_name);
                       \Session::put('email',$k->email);
                       \Session::put('mobile_no',$k->mobile_no);
                       \Session::put('gender',$k->gender);
                       \Session::put('password',$k->password);
                       \Session::put('role',$k->role);

                       switch($k->role){

                        case 'STUDENT':
                            return redirect()->route('student-home');
                            break;
                        case 'SCHOOL_ADMIN':
                            return redirect()->route('school-admin-home');
                            break;
                        case 'BUSINESS_OWNER':
                            return redirect()->route('business-owner-home');
                            break;
                        case 'SUPER_ADMIN':
                            return redirect()->route('super-admin-home');
                            break;
                       }
                    }
                }else{
                    $login_error="<div style='alert alert-danger'>Incorrect/Username/Password</div>";
                }

            }
        }
        return view('login',['login_error'=>$login_error,'signup_error'=>$signup_error]);
    }

    public function studentHome(Request $request){
        $data=$error="";
        $cart=array();
        if ($request->session()->get("cart")) {
            $cart=$request->session()->get("cart");
        }
        if ($request->input("product_name") && $request->input("product_price")) {
            $row=array('product_name'=>$request->input("product_name"),'product_price'=>$request->input("product_price"));
            array_push($cart, $row);
            \Session::put('cart',$cart);
            $error="<script>alert('added to cart');window.location.href='student-home';</script>Item was added to cart.";
        }
        $clubs=DB::select("select * from clubs");
        $products=DB::select("select * from products");
        $posts=DB::select("select * from posts");
        return view('student-home',['error'=>$error,'clubs'=>$clubs,'posts'=>$posts,'products'=>$products]);
    }

    public function superAdminHome(Request $request){
        $data=$error="";
        
        return view('super-admin-home',['error'=>$error,'data'=>$data]);
    }

    public function manageUsers(Request $request){

        return view("manage-users")
    }

    public function manageStudents(Request $request){

        return view("manage-users")
    }

    public function manageBusinessOwners(Request $request){

        return view("manage-business-owners")
    }

     public function manageSchoolAdmins(Request $request){

        return view("manage-business-owners")
    }

    public function schoolAdminHome(Request $request){
        $data=$error="";
        
        return view('school-admin-home',['error'=>$error,'data'=>$data]);
    }

    public function businessOwnerHome(Request $request){
        $data=$error="";
        
        return view('business-owner-home',['error'=>$error,'data'=>$data]);
    }

    public function clubsDisplay(Request $request){
      $error="";
      $clubs=DB::select("select * from clubs");
      if ($request->input("club_id") && $request->input("club_name") && $request->input("action")) {
                $action=$request->input("action");
                $club_id=$request->input("club_id");
                $club_name=$request->input("club_name");

                $cres=DB::insert("INSERT INTO manage_clubs (club_id, club_name, action, added_by, status) VALUES (?,?,?,?,?)",[$club_id,$club_name,$action,$added_by,$num]);

                $error="<div class='alert alert-success'>Joined club Successfully</div>";
            }
      return view("clubs",['clubs'=>$clubs,'error'=>$error]);  
    }
    public function chat(Request $request){
        $chats=array();
        $error="";
         $added_by=$request->session()->get("user_id");
        if ($request->isMethod('post')) {
           $message=$request->input('message');
           $cres=DB::insert("INSERT INTO chatbox (chat_from, message, added_by) VALUES (?,?,?)",[$request->session()->get("email"),$message,$added_by]);
           $error="message sent";
        }
       
        $chats=DB::select("select * from chatbox where chat_from=?",[$added_by]);
        $sent=DB::select("select * from chatbox where added_by=?",[$added_by]);
        return view("chat",['inbox'=>$chats,'sentbox'=>$sent,'error'=>$error]);
    }
    public function addProduct(Request $request){
        $data=array();
        $edit=$error=$product_name=$product_type=$product_image=$product_price=$user_id="";
        $added_by=$request->session()->get("user_id");

        if ($request->input('delete')) {
            $delete=$request->input('delete');
            DB::delete("delete from products where id=?",[$delete]);
            $error="<div class='alert alert-success'>Item Deleted Successfully</div>";
        }
        if ($request->isMethod('post')) {
            $product_name=$request->input("product_name");
            $product_type=$request->input("product_type");
            $file=$request->file("avatar");
            $avatar_name = $file->getClientOriginalName();
            $upload_dir="images";
            $file->move($upload_dir,$avatar_name);
            $file_path="images/".$avatar_name;
            $product_image=$file_path;
            $product_price=$request->input("product_price");
            $cres=DB::insert("INSERT INTO products (product_name, product_type, product_image, product_price, added_by) VALUES (?,?,?,?,?)",[$product_name,$product_type,$product_image,$product_price,$user_id]);

            if (!empty($request->input('edit'))) {
                DB::update("UPDATE products set product_name=?,product_type=?, product_image=?, product_price=?, added_by=? where id=? ",[$product_name,$product_type,$product_image,$product_price,$user_id,$request->input('edit')]);
                $error="<div class='alert alert-success'>Item Updated Successfully</div>";
            }else{
                DB::insert("",[]);
                $error="<div class='alert alert-success'>Item Created Successfully</div>";
            }
        }
        $data=DB::select("select * from products");
        return view('add-product',['error'=>$error,'data'=>$data,'product_name'=>$product_name,'product_type'=>$product_type,'product_image'=>$product_image,'product_price'=>$product_price,'id'=$edit]);
    }

    public function addOrder(Request $request){
        $data=array();
        $error="";
        $added_by=$request->session()->get("user_id");
        if ($request->input('delete')) {
            $delete=$request->input('delete');
            DB::delete("delete from where =?",[$delete]);
            $error="<div class='alert alert-success'>Item Deleted Successfully</div>";
        }
        if ($request->isMethod('post')) {
            $order_details=$request->input("order_details");
            $total=$request->input("total");
            $status=1;
            
            if (!empty($request->input('edit'))) {
                //DB::update("",[]);
                //$error="<div class='alert alert-success'>Item Updated Successfully</div>";
            }else{
                $cres=DB::insert("INSERT INTO orders (order_details, total, status, added_by) VALUES (?,?,?,?)",[$order_details,$total,$status,$added_by]);
                $error="<div class='alert alert-success'>Order Created Successfully</div>";
            }
        }
        $data=DB::select("select * from orders where added_by=?",[$added_by]);
        return view('add-product',['error'=>$error,'data'=>$data]);
    }

    public function addClub(Request $request){
        $data=$error=$club_id=$club_name="";
        if ($request->input('edit')) {
           $edit=$request->input('edit');
           $data=DB::select("select * from clubs where id=?",[$edit]);
           foreach ($data as $k) {
              $club_id=$k->club_id;
              $club_name=$k->club_name;

           }
        }
        if ($request->input('delete')) {
            $delete=$request->input('delete');
            DB::delete("delete from clubs where id=?",[$delete]);
            $error="<div class='alert alert-success'>Item Deleted Successfully</div>";
        }
        if ($request->isMethod('post')) {
            $club_id=$request->input('club_id');
            $club_name=$request->input('club_name');
            $action=$request->input('action');
            $added_by=$request->session()->get("user_id");
            $num=$request->input('num');
            $file=$request->file("avatar");
            $avatar_name = $file->getClientOriginalName();
            $upload_dir="images";
            $file->move($upload_dir,$avatar_name);
            $file_path="images/".$avatar_name;
            $club_image=$file_path;

            if (!empty($request->input('edit'))) {
                DB::update("UPDATE manage_clubs set club_name=?, action=?, added_by=?, club_image=?, status=? where id=?",[$club_name,$action,$added_by,$num,$club_id]);
                $error="<div class='alert alert-success'>Item Updated Successfully</div>";
            }else{
               $cres=DB::insert("INSERT INTO manage_clubs (club_id, club_name, action, added_by, status,club_image) VALUES (?,?,?,?,?,?)",[$club_id,$club_name,$action,$added_by,$num,$club_image]);
                $error="<div class='alert alert-success'>Item Created Successfully</div>";
            }
        }
        
        return view('add-club',['error'=>$error,'data'=>$data,'club_name'=>$club_name,'club_id'=>$club_id,'action'=>'','num'=>'']);
    }

    public function addPost(Request $request){
        $data=array();
        $error=$post_title=$post_desp="";
        if ($request->input('edit')) {
           $edit=$request->input('edit');
           $data=DB::select("select * from posts where id=?",[$edit]);
           foreach ($data as $k) {
               $post_desp=$k->post_desp;
               $post_title=$k->post_title;
           }
        }
        if ($request->input('delete')) {

            $delete=$request->input('delete');
            DB::delete("delete from posts where post_id=?",[$delete]);
            $error="<div class='alert alert-success'>Item Deleted Successfully</div>";
        }
        if ($request->isMethod('post')) {
            $post_title=$request->input("post_title");
            $post_desp=$request->input("post_desp");

             $file=$request->file("avatar");
            $avatar_name = $file->getClientOriginalName();
            $upload_dir="images";
            $file->move($upload_dir,$avatar_name);
            $file_path="images/".$avatar_name;

            $post_image=$file_path;
            $user_id=$request->session()->get("user_id");

            if (!empty($request->input('edit'))) {
                DB::update("UPDATE posts set post_title=?, post_desp=?, post_image=?, added_by=? where id=?",[$post_title,$post_desp,$post_image,$user_id,$request->input('edit')]);
                $error="<div class='alert alert-success'>Item Updated Successfully</div>";
            }else{
                $cres=DB::insert("INSERT INTO posts (post_title, post_desp, post_image, added_by) VALUES (?,?,?,?)",[$post_title,$post_desp,$post_image,$user_id]);
                $error="<div class='alert alert-success'>Item Created Successfully</div>";
            }
        }
        $data=DB::select("select * from posts");
        return view('add-post',['error'=>$error,'data'=>$data,'post_desp'=>$post_desp,'post_title'=>$post_title]);
    }



    public function addPromotion(Request $request){
        $data=array();
        $error=$prod_name=$promotion_type=$approach_media=$product_message=$user_id="";
        if ($request->input('edit')) {
           $edit=$request->input('edit');
           $data=DB::select("select * from promotions where id=?",[$edit]);
           foreach ($data as $k) {
               $prod_name=$k->prod_name;
               $promotion_type=$k->promotion_type;
               $approach_media=$k->approach_media;
               $product_message=$k->product_message;
           }
        }
        if ($request->input('delete')) {

            $delete=$request->input('delete');
            DB::delete("delete from promotions where id=?",[$delete]);
            $error="<div class='alert alert-success'>Item Deleted Successfully</div>";
        }
        if ($request->isMethod('post')) {
            $prod_name=$request->input("product_name");
            $promotion_type=$request->input("promotion_type");
            
            $product_message=$request->input("product_message");

             $file=$request->file("avatar");
            $avatar_name = $file->getClientOriginalName();
            $upload_dir="images";
            $file->move($upload_dir,$avatar_name);
            $file_path="images/".$avatar_name;
            $approach_media=$file_path;
            $user_id=$request->session()->get("user_id");

            if (!empty($request->input('edit'))) {
                DB::update("");
                $error="<div class='alert alert-success'>Item Updated Successfully</div>";
            }else{
                $cres=DB::insert("INSERT INTO promotions (prod_name, promotion_type, approach_media, product_message, added_by) VALUES (?,?,?,?,?)",[$prod_name,$promotion_type,$approach_media,$product_message,$user_id]);

                $error="<div class='alert alert-success'>Item Created Successfully</div>";
            }
        }
        $data=DB::select("select * from promotions");
        return view('add-promotions',['error'=>$error,'data'=>$data,'prod_name'=>$prod_name,'promotion_type'=>$promotion_type]);
    }


    public function manageClubs(Request $request){
        $data=array();
        $error=$prod_name=$promotion_type=$approach_media=$product_message=$user_id="";
        $added_by=$request->session()->get("user_id");
        if ($request->input('delete')) {

            $delete=$request->input('delete');
            DB::delete("delete from manage_clubs where club_id=? and added_by=?",[$delete,$added_by]);
            $error="<div class='alert alert-success'>Left Successfully</div>";
        }
        if ($request->isMethod('post')) {
            
            $user_id=$request->session()->get("user_id");

            if (!empty($request->input('edit'))) {
                
            }else{
                $action="joined";
                $club_id=$request->input("club_id");
                $club_name=$request->input("club_name");

                $cres=DB::insert("INSERT INTO manage_clubs (club_id, club_name, action, added_by, status) VALUES (?,?,?,?,?)",[$club_id,$club_name,$action,$added_by,$num]);

                $error="<div class='alert alert-success'>Joined club Successfully</div>";
            }
        }
        $data=DB::select("select * from manage_clubs where added_by=?",[$added_by]);
        return view('manage-clubs',['error'=>$error,'data'=>$data]);
    }




    public function goodsCart(Request $request){
        $items=array();
        if ($request->session()->get('cart')) {
            $items=$request->session()->get('cart');
        }
        if ($request->input('checkout')) {
            // code...
        }
    }
}
