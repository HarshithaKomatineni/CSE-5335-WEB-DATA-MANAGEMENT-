@extends("template")


@section("content")
<h2>MESSAGING</h2>
<div class="row">
	<div class="col-sm-8 col-md-8 col-xs-12">
		
		<hr>INBOX
<table>
	<thead>
		<tr>
			<th>From</th><th>Message</th><<th>Added By</th>
		</tr>
	</thead>
	<tbody>
		@foreach($inbox as $d)
			<tr>
				<td>{{$d->chat_from}}</td> <td>{{$d->message}}</td> <td>{{$d->added_by}}</td>
			</tr>
		@endforeach
	</tbody>
</table>

<hr>OUTBOX
<table>
	<thead>
		<tr>
			<th>From</th><th>Message</th><<th>Added By</th>
		</tr>
	</thead>
	<tbody>
		@foreach($sentbox as $d)
			<tr>
				<td>{{$d->chat_from}}</td> <td>{{$d->message}}</td> <td>{{$d->added_by}}</td>
			</tr>
		@endforeach
	</tbody>
</table>


	</div>
	<div class="col-sm-4 col-md-4 col-xs-12">
		<form method="POST">
			<textarea class="for-control">
				enter message..
			</textarea>
			<button type="submit" class="btn btn-primary">SEND</button>
		</form>
	</div>
</div>

@stop