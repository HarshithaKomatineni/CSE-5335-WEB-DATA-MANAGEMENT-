@extends("template")
@section("content")

<a href="manage-students" class="btn btn-info">Manage Students</a>
<a href="manage-business-owners" class="btn btn-info">Manage Business Owners</a>
<a href="manage-school-admins" class="btn btn-info">Manage School Admins</a>
<a href="add-posts" class="btn btn-info">Manage Promotions</a>

@stop