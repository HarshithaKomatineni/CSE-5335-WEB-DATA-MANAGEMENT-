@extends("template")


@section("content")

{!! $error !!}
<div class="row">
<div class="col-sm-4 col-md-4 col-xs-12 col-lg-4">
	<form method="POST" enctype="multipart/form-data">
		
		<div class="form-group">
				<b>CLUB NAME: </b>
				<input type="text" name="product_name" class="form-control" value="{{$club_name}}" required>
			</div>

			<div class="form-group">
				<b>ACTION: </b>
				<input type="text" name="action" class="form-control" value="{{$action}}" required>
			</div>

			<div class="form-group">
				<b>NUM.: </b>
				<input type="text" name="num" class="form-control" value="{{$num}}" required>
			</div>

			<div class="form-group">
				<b>CLUB IMAGE: </b>
				<input type="file" name="avatar" class="form-control" required>
			</div>

			
			<input type="hidden" name="club_id" value="{{$p->club_id}}">

		<button type="submit" class="btn btn-primary">SAVE</button>
	</form>

</div>

<div class="col-sm-8 col-md-8 col-xs-12 col-lg-8">

	<div class="row" style="display: flex;flex-wrap: wrap;">
		@foreach($data as $p)
		<div class="col-sm-3 col-md-3 col-xs-12 col-lg-3">
			<div class="thumbnail">
				<img src="{{url($p->club_image)}}" class="img-responsive">
				<div class="caption">
					<b>{{$p->club_name}}</b>
					{{$p->num}}<br>
					<a href="?delete={{$p->id}}">Delete</a>
				</div>
			</div>
		</div>
		@endforeach
	</div>
</div>
</div>
@stop