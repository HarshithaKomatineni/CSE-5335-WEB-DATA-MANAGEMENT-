@extends("template")
@section("content")
<a href="add-posts" class="btn btn-info">Manage Promotions</a>
<a href="add-products" class="btn btn-info">Manage Products</a>
@stop