@extends("template")


@section("content")

{!! $error !!}
<div class="row">
	<div class="col-sm-4 col-md-4 col-xs-12 col-lg-4">
		<h3>NEW</h3>
		<form method="POST" enctype="multipart/form-data">
			<div class="form-group">
				<b>PRODUCT NAME: </b>
				<input type="text" name="product_name" class="form-control" value="{{$product_name}}" required>
			</div>

			<div class="form-group">
				<b>PRODUCT PRICE: </b>
				<input type="text" name="product_price" value="{{$product_price}}" class="form-control" required>
			</div>

			<div class="form-group">
				<b>PRODUCT TYPE: </b>
				<input type="text" value="{{$product_type}}" name="product_type" class="form-control" required>
			</div>

			<input type="hidden" name="edit" value="{{i$d}}">

			<div class="form-group">
				<b>PRODUCT IMAGE: </b>
				<input type="file" name="avatar" class="form-control" required>
			</div>
			<button type="submit">UPLOAD ITEM</button>
		</form>

	</div>
		<div class="col-sm-8 col-md-8 col-xs-12 col-lg-8">
		
		<h3>ITEMS</h3>
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>NAME</th> <th>PRICE</th> <th>PHOTO</th> <th>PRODUCT TYPE</th> <th>ACTION</th>
				</tr>
			</thead>
			<tbody>
				@foreach($data as $p)
					<tr>
						<td>{{$p->product_name}}</td> <td>{{$p->product_price}}</td> <td><img src="{{url($p->product_image)}}" style="width: 64px;height: 64px;"></td> <td>{{$p->product_type}}</td> <td><a href="?delete={{$p->id}}">DELETE</a></td>
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</div>

@stop