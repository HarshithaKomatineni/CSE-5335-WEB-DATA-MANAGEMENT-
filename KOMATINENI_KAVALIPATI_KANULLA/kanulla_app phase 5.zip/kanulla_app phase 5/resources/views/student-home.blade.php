@extends("template")
@section("content")
{!! $error !!}
<div class="me-lg-9">


							
							<div class="product_sss">
								<div class="pp_product_section">
									<div class="pp_title">
										<h3>Products</h3>
										<div class="add_product">
											<a href="#/add_product">
												<button class="add_new">Add Product</button>
											</a>
											<div class="add_prod_block" id="prod_pop">
												<div class="popup_title">
													<h3>Add New Product</h3>
												</div>
												<div class="inner_prod_block">
													<div class="image-block">
														
													</div>
													<div class="prod_sse">
														<ul>
															<li>
																<h3>Product Title</h3>
																<input type="text" placeholder="Title">
															</li>
															<li>
																<h3>Price</h3>
																<input type="text" placeholder="Price">
															</li>
															<li>
																<button class="cancel_prod">Cancel</button>
																<button class="new_prod">Add</button></li>
															</ul>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="me-row">

										@foreach($products as $p)

											<div class="me-md-4">
												<div class="product-item">
													<div class="product-image">
														<a href="#/profile">
															<img src="{{url($p->product_image)}}" alt="Product Image">
														</a>
														<div class="product-action">
															<a href="?add-cart&product_name={{$p->product_name}}&product_price={{$p->product_price}}">
																<i class="fa fa-cart-plus"></i>
															</a>
														</div>
													</div>
													<div class="product-price"><a>{{$p->product_name}}</a><h3><span>$</span>{{$p->product_price}}</h3></div>

												</div>
											</div>
										@endforeach
									
									</div>
								</div><div class="club_sss">
									<div class="pp_product_section">
										<div class="pp_title">
											<h3>Clubs</h3>
											<div class="add_product">
												<a href="add-club">
													<button class="add_new">Add Club</button>
												</a>
												<div class="add_prod_block " id="club_pop">
													<div class="popup_title">
														<h3>Add New Club</h3>
													</div>
													<div class="inner_prod_block">
														<div class="image-block">
															
														</div>
														<div class="prod_sse">
															<ul>
																<li>
																	<h3>Club Title</h3>
																	<input type="text" placeholder="Title">
																</li>
																<li>
																	<h3>Description</h3>
																	<textarea placeholder="Write few words about event">
																		
																	</textarea>
																</li>
																<li>
																	<button class="cancel_prod">Cancel</button>
																	<button class="new_prod">Add </button>
																</li>
															</ul>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="me-row">
										
										@foreach($clubs as $p)

											<div class="me-md-4">
												<div class="product-item">
													<div class="product-image">
														<a href="#/profile">
															<img src="{{url($p->club_image)}}" alt="Product Image">
														</a>
														
													</div>
													<div class="product-price"><h3><span></span>{{$p->club_name}}</h3></div>

												</div>
											</div>
										@endforeach
										
									</div>
									</div>
								</div>
								<div class="posts_sss">
									<div class="pp_product_section">
										<div class="pp_title">
											<h3>Posts</h3>
											<div class="add_product">
												<a href="add-post">
													<button class="add_new">Add Post</button>
												</a>
												<div class="add_prod_block " id="club_pop">
													<div class="popup_title">
														<h3>Add New Post</h3>
													</div>
													<div class="inner_prod_block">
														<div class="image-block">
															
														</div>
														<div class="prod_sse">
															<ul>
																<li><h3>Post Title</h3>
																<input type="text" placeholder="Title">
															</li>
															<li>
																<h3>Description</h3>
																<textarea placeholder="Write few words about event">
																	
																</textarea>
															</li>
															<li>
																<button class="cancel_prod">Cancel</button>
																<button class="new_prod">Add</button>
															</li>
														</ul>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="me-row">
									
										@foreach($posts as $p)

										<div class="me-md-4">
												<div class="product-item">
													<div class="product-image">
														<a href="#/profile">
															<img src="{{url($p->post_image)}}" alt="Product Image">
														</a>
														
													</div>
													<div class="product-price"><h3><span></span>{{$p->post_title}}</h3><div class="post_p">{{$p->post_desp}}</div></div>

												</div>
											</div>
										@endforeach
										
									</div>
								</div>





@stop