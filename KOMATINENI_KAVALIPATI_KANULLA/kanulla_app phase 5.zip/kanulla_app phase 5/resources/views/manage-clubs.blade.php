@extends("template")


@section("content")
<h3>MANAGE CLUBS</h3><hr>
<div class="row" style="display:flex; flex-wrap: wrap;">
	@foreach($clubs as $p)

		<div class="col-sm-3 col-md-3 col-xs-12 col-lg-3">
			<div class="card card-primary">
				<div class="card-header">{{$p->club_name}}</div>
				<div class="card-body">
					<img src="{{url($p->club_image)}}" class="img-responsive">
					<div class="caption">
						<a href="?join={{$->club_id}}" class="btn btn-info">JOIN CLUB</a>
					</div>
				</div>
			</div>
		</div>
	@endforeach
</div>


@stop