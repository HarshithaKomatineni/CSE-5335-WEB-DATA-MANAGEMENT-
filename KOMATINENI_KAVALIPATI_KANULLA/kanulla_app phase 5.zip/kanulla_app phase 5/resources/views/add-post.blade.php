@extends("template")


@section("content")

{!! $error !!}
<div class="row">
<div class="col-sm-4 col-md-4 col-xs-12 col-lg-4">
	<form method="POST">
		
		<div class="form-group">
				<b>POST TITLE: </b>
				<input type="text" name="post_title" class="form-control" value="{{$post_title}}" required>
			</div>

			<div class="form-group">
				<b>POST DESP.: </b>
				<input type="text" name="post_desp" class="form-control" value="{{$post_desp}}" required>
			</div>

			<div class="form-group">
				<b>POST IMAGE: </b>
				<input type="file" name="avatar" class="form-control" required>
			</div>

		<button type="submit" class="btn btn-primary">SAVE</button>
	</form>

</div>

<div class="col-sm-8 col-md-8 col-xs-12 col-lg-8">

	<div class="row" style="display: flex;flex-wrap: wrap;">
		@foreach($data as $p)
		<div class="col-sm-3 col-md-3 col-xs-12 col-lg-3">
			<div class="thumbnail">
				<img src="{{url($p->post_image)}}" class="img-responsive">
				<div class="caption">
					Title: <b>{{$p->post_title}}</b>
					{{$p->post_desp}}<br>
					<a href="?delete={{$p->id}}">Delete</a>
				</div>
			</div>
		</div>
		@endforeach
	</div>
</div>
</div>
@stop